#!/bin/bash

rm energy*
rm slurm*
rm output.out
rm trajectory*
rm running_*
rm fort.*
rm forces*
rm runtime_info.dat

