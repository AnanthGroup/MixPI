#!/bin/bash
#SBATCH -N 1
#SBATCH -J 1024x
#SBATCH -t 2:00:00
#SBATCH --ntasks-per-node=32
#SBATCH --cpus-per-task=2

source /cp2k-2023.2/tools/toolchain/install/setup

srun --cpu_bind core cp2k_pimd.out

